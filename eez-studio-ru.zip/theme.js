(() => {
  const key = "eez-studio-ru-theme";
  const root = document.documentElement;
  const localFile = location.protocol === "file:";
  const isExplicit = value => value === "light" || value === "dark";
  let theme = "system";

  try {
    const saved = localStorage.getItem(key);
    if (isExplicit(saved)) theme = saved;
  } catch {
    // The system setting is available when the browser blocks storage.
  }

  const urlTheme = new URL(location.href).searchParams.get("theme");
  if (localFile && isExplicit(urlTheme)) theme = urlTheme;

  function apply(value) {
    if (isExplicit(value)) root.dataset.theme = value;
    else delete root.dataset.theme;
  }

  function persist(value) {
    try {
      if (isExplicit(value)) localStorage.setItem(key, value);
      else localStorage.removeItem(key);
    } catch {
      // Local file navigation also carries the choice in the URL.
    }
  }

  function applyToLocalLinks(value) {
    for (const link of document.querySelectorAll("a[href]")) {
      const url = new URL(link.href);
      if (url.protocol !== "file:" || !url.pathname.endsWith("/index.html")) continue;
      if (isExplicit(value)) url.searchParams.set("theme", value);
      else url.searchParams.delete("theme");
      link.href = url.href;
    }
  }

  apply(theme);
  document.addEventListener("DOMContentLoaded", () => {
    const control = document.querySelector(".theme-control");
    const select = control.querySelector("select");
    select.value = theme;
    control.hidden = false;
    if (localFile && isExplicit(theme)) applyToLocalLinks(theme);

    select.addEventListener("change", () => {
      const value = select.value;
      apply(value);
      persist(value);
      if (!localFile) return;
      const currentUrl = new URL(location.href);
      if (isExplicit(value)) currentUrl.searchParams.set("theme", value);
      else currentUrl.searchParams.delete("theme");
      if (currentUrl.href === location.href) applyToLocalLinks(value);
      else location.replace(currentUrl.href);
    });
  });
})();
